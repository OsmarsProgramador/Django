states = {
    "Norte": {
        "AC": "Acre",
        "AM": "Amazonas",
        "AP": "Amapá",
        "PA": "Pará",
        "RO": "Rondônia",
        "RR": "Roraima",
        "TO": "Tocantins"
    },
    "Nordeste": {
        "AL": "Alagoas",
        "BA": "Bahia",
        "CE": "Ceará",
        "MA": "Maranhão",
        "PB": "Paraíba",
        "PE": "Pernambuco",
        "PI": "Piauí",
        "RN": "Rio Grande do Norte",
        "SE": "Sergipe"
    },
    "Sul": {
        "PR": "Paraná",
        "RS": "Rio Grande do Sul",
        "SC": "Santa Catarina"
    },
    "Sudeste": {
        "ES": "Espírito Santo",
        "MG": "Minas Gerais",
        "RJ": "Rio de Janeiro",
        "SP": "São Paulo"
    },
    "Centro-Oeste": {
        "GO": "Goiás",
        "MS": "Mato Grosso do Sul",
        "MT": "Mato Grosso"
    }
}
