from django.apps import AppConfig
class NotafiscalConfig(AppConfig):
    name = 'notafiscal'
